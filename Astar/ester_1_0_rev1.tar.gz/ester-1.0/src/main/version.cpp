#include "version.h"
#include"stdio.h"

int main() {

	printf("Version %s\n",ESTER_VERSION);

}
