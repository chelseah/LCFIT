#ifndef _STAR_H
#define _STAR_H

#include"matrix.h"
#include"solver.h"
#include"numdiff.h"
#include"mapping.h"
#include"physics.h"
#include"constants.h"
#include"parser.h"
#include"graphics.h"

#include<cmath>

class star1d;

class star2d {
  protected:
	virtual void copy(const star2d &);
	void init1d(const star1d &A,int npts_th,int npts_ex);
	virtual int check_tag(const char *tag) const;
	virtual void write_tag(OUTFILE *fp,char mode) const;
  public:
  	mapping map;
  	const int &nr,&nth,&nex,&ndomains;
	const matrix &r,&z,&th,&Dt,&Dt2,&zex,&Dex,&rex;
	const matrix_block_diag &D;
    matrix rho,phi,p,T,Xr;
    matrix phiex;
	matrix vr,vt,G,w;
    double X,Y,Z;
    double R,M;
    double rhoc,Tc,pc;
    double Omega,Omega_bk,Omegac;
   	double Ekman;
  	opa_struct opa;
	nuc_struct nuc;
	eos_struct eos;
	char atm_name[16];
	matrix ps,Ts;
	double m,pi_c,Lambda;
	double surff;
	int conv;
	double Xc;
	int core_convec;
	double min_core_size;
	
	char version[32];

	struct units_struct {
		double rho,p,phi,T,Omega,r,v,F;
	} units;
	void calc_units();

	star2d();
	virtual ~star2d();
	star2d(const star2d &);
	star2d &operator=(const star2d &);
	struct config_struct {
		double newton_dmax;
		int verbose;
	} config;
	
	int opacity();
	int nuclear();
	int eq_state();

	virtual int init(const char *input_file,const char *param_file,int argc,char *argv[]);
	virtual int check_arg(char *arg,char *val,int *change_grid);
	virtual int read(const char *input_file);
	virtual int read_old(const char *input_file);
	virtual void write(const char *output_file,char output_mode='b') const;
	virtual void interp(mapping_redist *red);
	
	virtual void dump_info();
	
	virtual solver *init_solver(int nvar_add=0);
	virtual double solve(solver *);
	virtual void register_variables(solver *op);
	
	virtual void solve_poisson(solver *);
	virtual void solve_pressure(solver *);
	virtual void solve_temp(solver *);
	virtual void solve_dim(solver *);
	virtual void solve_map(solver *);
	virtual void solve_Omega(solver *);
	virtual void solve_rot(solver *);
	virtual void solve_dyn(solver *);
	virtual void solve_gsup(solver *);
	virtual void solve_Teff(solver *);
	virtual void solve_vbl(solver *,const char *eqn,matrix &rhs);
	virtual void solve_definitions(solver *);
	
	virtual void update_map(matrix dR);
	
	virtual void atmosphere();
	virtual void solve_atm(solver *);
	virtual void atm_simple();
	virtual void solve_atm_simple(solver *);

	
	virtual void upd_Xr();
	virtual void calc_veloc();
	
	virtual double luminosity() const;
	virtual matrix Teff() const;
	virtual matrix N2() const;
	virtual matrix gsup() const;
	virtual double virial_3P() const;
	virtual double virial_L() const;
	virtual double virial_W() const;
	virtual double virial_ps() const;
	virtual double virial() const;
	virtual double energy_test() const;
	virtual matrix stream() const;
	virtual double apparent_luminosity(double i) const;
	
	virtual void fill();
	
	// star_map.cpp
	virtual void remap(int ndomains,int *npts,int nth,int nex);
	virtual matrix check_boundaries(int ndomains,int &conv_new,double p_cc=0) const;
	virtual matrix find_boundaries(matrix pif) const;
	virtual void check_map();
	virtual int check_convec(double &p_cc,matrix &Rcc);
	
	void draw(figure *,const matrix &,int parity=0) const;
	void drawi(figure *,const matrix &,int sr,int st,int parity=0) const;
	void drawc(figure *,const matrix &,int ncontours,int parity=0) const;
	void drawci(figure *,const matrix &,int sr,int st,int ncontours,int parity=0) const;
	void spectrum(figure *,const matrix &,int parity=0) const;

	virtual void check_jacobian(solver *op,const char *eqn);

};

class star1d : public star2d {
  protected:
    virtual int check_tag(const char *tag) const;
	virtual void write_tag(OUTFILE *fp,char mode) const;
  public:	
  	// star1d_class.cpp
	star1d();
	~star1d();
	star1d(const star1d &);
	star1d &operator=(const star1d &);
	virtual int init(const char *input_file,const char *param_file,int argc,char *argv[]);
	virtual int check_arg(char *arg,char *val,int *change_grid);
	virtual int read_old(const char *input_file);
	
	virtual void dump_info();
	
	virtual solver *init_solver(int nvar_add=0);
	virtual void register_variables(solver *op);
	virtual double solve(solver *);
	virtual void solve_poisson(solver *);
	virtual void solve_pressure(solver *);
	virtual void solve_temp(solver *);
	virtual void solve_dim(solver *);
	virtual void solve_map(solver *);
	virtual void solve_definitions(solver *);
	virtual void solve_Teff(solver *);
	virtual void solve_gsup(solver *);
	
	virtual void atmosphere();
	virtual void solve_atm(solver *);
	virtual void atm_simple();
	virtual void solve_atm_simple(solver *);
	
	virtual void update_map(matrix dR);
	
	virtual void upd_Xr();
	
	
	
	virtual matrix N2() const;
	virtual double luminosity() const;
	virtual matrix Teff() const;
	virtual matrix gsup() const;
	
	virtual void fill();
	
	void spectrum(figure *,const matrix &,const char *line="") const;
	
	virtual void check_jacobian(solver *op,const char *eqn);
};

#endif


