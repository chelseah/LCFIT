#ifndef _VERSION_H
#define _VERSION_H

#define ESTER_VERSION "1.0.0"

#endif
